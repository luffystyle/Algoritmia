// la siguiente línea hace que Tree sea equivalente a int,
// cambiar por una definición apropiada de Tree
typedef int Tree;

Tree Tree_read(char* strTree){
	return 1;
}

void Tree_write(Tree tree, char* str) {
	*str = '\0';
}
