#include <stdio.h>
#include "p2.h"

typedef struct TestItem TestItem;
struct TestItem {
	char* strTree;
	char node;
	char* expectedResult;
};

int runTest(TestItem testItem, int nTest) {
	char* strTree = testItem.strTree;
	char node = testItem.node;
	char* expectedResult = testItem.expectedResult;

	printf("\n%d) Probando: \"%s\" - nodo: \"%c\"\n", nTest, strTree, node);
	fflush(stdout);
	char result[256];
	Tree_invertFromNode(strTree, node, result);
	if (strcmp(result, expectedResult) == 0) {
		printf("Correcto: \"%s\"\n", expectedResult);
		fflush(stdout);
		return 1;
	} else {
		printf(">> Incorrecto:\n   Esperado: \"%s\"\n   Obtenido: \"%s\" \n", expectedResult, result);
		fflush(stdout);
		return 0;
	}
}

void addTestItem(TestItem* testItems, int* nTests, char* strTree, char node, char* expectedResult) {
	TestItem testItem;
	testItem.strTree = strTree;
	testItem.node = node;
	testItem.expectedResult = expectedResult;
	testItems[*nTests] = testItem;
	*nTests = (*nTests) + 1;
}

void runTests(TestItem* testItems, int nTests) {
	int i;
	int correct = 0;
	int incorrect = 0;
	for (i = 0; i < nTests; i++) {
		TestItem testItem = testItems[i];
		if (runTest(testItem, i)) correct++;
		else incorrect++;
	}

	printf("\nResumen:\nPruebas correctas:   %4d (%3.2f %%)\nPruebas incorrectas: %4d (%3.2f %%)\n", correct, (float) correct / nTests * 100, incorrect, (float) incorrect / nTests * 100);
}

int main(int argc, char** argv) {
	TestItem testItems[512];
	int nTests = 0;

	addTestItem(testItems, &nTests, "a(b)", 'b', "b(a)");
	addTestItem(testItems, &nTests, "a(b)", 'a', "a(b)");
	addTestItem(testItems, &nTests, "a(bc)", 'b', "b(a(c))");
	addTestItem(testItems, &nTests, "m(no(pq))", 'q', "q(o(pm(n)))");
	addTestItem(testItems, &nTests, "m(no(pq))", 'o', "o(pqm(n))");
	addTestItem(testItems, &nTests, "m(no(pq))", 'n', "n(m(o(pq)))");
	addTestItem(testItems, &nTests, "m(no(pq))", 'p', "p(o(qm(n)))");
	addTestItem(testItems, &nTests, "a(bc(d(m(op(w(zy)x(jk)))n)e))", 'p', "p(w(zy)x(jk)m(od(nc(ea(b)))))");
	addTestItem(testItems, &nTests, "a(bc(d(m(op(w(zy)x(jk)))n)e))", 'a', "a(bc(d(m(op(w(zy)x(jk)))n)e))");
	addTestItem(testItems, &nTests, "a(bc(d(m(op(w(zy)x(jk)))n)e))", 'x', "x(jkp(w(zy)m(od(nc(ea(b))))))");

	runTests(testItems, nTests);

	return 0;
}
