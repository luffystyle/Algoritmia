#include <stdio.h>
#include <string.h>
#include "p1.h"

typedef struct TestItem TestItem;
struct TestItem {
	char* strTree;
};

int runTest(TestItem testItem, int nTest) {
	char* strTree = testItem.strTree;

	printf("\n%d) Probando: \"%s\"\n", nTest, strTree);
	fflush(stdout);
	
	char result[256];
	Tree_write(Tree_read(strTree), result);

	if (strcmp(result, strTree) == 0) {
		printf("Correcto: %s\n", strTree);
		fflush(stdout);
		return 1;
	} else {
		printf(">> Incorrecto:\n   Esperado: %s\n   Obtenido: %s \n", strTree, result);
		fflush(stdout);
		return 0;
	}
}

void addTestItem(TestItem* testItems, int* nTests, char* strTree) {
	TestItem testItem;
	testItem.strTree = strTree;
	testItems[*nTests] = testItem;
	*nTests = (*nTests) + 1;
}

void runTests(TestItem* testItems, int nTests) {
	int i;
	int correct = 0;
	int incorrect = 0;
	for (i = 0; i < nTests; i++) {
		TestItem testItem = testItems[i];
		if (runTest(testItem, i)) correct++;
		else incorrect++;
	}

	printf("\nResumen:\nPruebas correctas:   %4d (%3.2f %%)\nPruebas incorrectas: %4d (%3.2f %%)\n", correct, (float) correct / nTests * 100, incorrect, (float) incorrect / nTests * 100);
}

int main(int argc, char** argv) {
	TestItem testItems[512];
	int nTests = 0;

	addTestItem(testItems, &nTests, "a(bc)");
	addTestItem(testItems, &nTests, "a(wb(s)cx)");
	addTestItem(testItems, &nTests, "a(x(bc)y)");
	addTestItem(testItems, &nTests, "w(m(efg)y(xwq)nop)");
	addTestItem(testItems, &nTests, "m(ab(q(v)s)cdef(gk))");
	addTestItem(testItems, &nTests, "m(j(wop)b(qg(v)s)cf(gk))");
	addTestItem(testItems, &nTests, "a");
	addTestItem(testItems, &nTests, "a(b(c(d(e))))");
	addTestItem(testItems, &nTests, "a(xw(w(ww)))");
	addTestItem(testItems, &nTests, "b(m(mnop)no(mnop)p)");
	
	runTests(testItems, nTests);

	return 0;
}
