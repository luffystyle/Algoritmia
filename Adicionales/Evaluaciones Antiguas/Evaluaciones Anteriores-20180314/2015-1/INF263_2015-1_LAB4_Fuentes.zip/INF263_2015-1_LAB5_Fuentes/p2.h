#include "p1.h"

void Tree_invertFromNode(char* strTree, char nodeChar, char* newStrTree) {
	*newStrTree = '\0';
}