#ifndef AMISTAD_H
#define	AMISTAD_H

#include "RedSocial.h"
#include "Fecha.h"

struct Amistad {
    Usuario* usuario;
    Fecha fechaInicio;
};

#endif	/* AMISTAD_H */

