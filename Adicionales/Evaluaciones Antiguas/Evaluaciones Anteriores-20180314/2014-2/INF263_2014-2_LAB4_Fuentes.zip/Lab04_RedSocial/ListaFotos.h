/* 
 * File:   ListaFotos.h
 * Author: junior
 *
 * Created on November 3, 2014, 1:06 AM
 */

#ifndef LISTAFOTOS_H
#define	LISTAFOTOS_H

#include "RedSocial.h"

struct ListaFotos {
};

#endif	/* LISTAFOTOS_H */

