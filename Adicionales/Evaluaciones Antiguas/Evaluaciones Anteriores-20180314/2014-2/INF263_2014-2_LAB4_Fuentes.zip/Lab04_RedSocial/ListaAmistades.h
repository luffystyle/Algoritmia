/* 
 * File:   ListaAmistades.h
 * Author: junior
 *
 * Created on November 3, 2014, 1:05 AM
 */

#ifndef LISTAAMISTADES_H
#define	LISTAAMISTADES_H

#include "RedSocial.h"

struct ListaAmistades {
};

#endif	/* LISTAAMISTADES_H */

