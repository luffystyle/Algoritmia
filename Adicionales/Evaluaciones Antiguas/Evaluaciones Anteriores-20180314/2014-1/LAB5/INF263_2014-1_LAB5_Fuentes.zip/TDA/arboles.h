#define BINARIO_VACIO NULL
#define NODO_NULO NULL

typedef int tEtiqueta;                   /*Algun tipo adecuado*/
typedef struct tipoceldaBin {
           struct tipoceldaB *padre,*hizqda,*hdrcha;
           tEtiqueta etiqueta;
         }*nodoBin;
typedef nodoBin tArbolBin;

tArbolBin Crear0(tEtiqueta et);
tArbolBin Crear2(tEtiqueta et,tArbolBin ti,tArbolBin td);
void Destruir(tArbolBin A);
nodoBin Padre(nodoBin n,tArbolBin A);
nodoBin Hderecha(nodoBin n,tArbolBin A);
nodoBin Hizquierda(nodoBin n,tArbolBin A);
tEtiqueta Etiqueta(nodoBin n,tArbolBin A);
void ReEtiqueta(tEtiqueta e,nodoBin n,tArbolBin A);
nodoBin Raiz(tArbolBin A);
void InsertarHijoIzda(nodoBin n,tArbolBin ah,tArbolBin A);
void InsertarHijoDrchaB(nodoBin n,tArbolBin ah,tArbolBin A);
tArbolBin PodarHijoIzqda(nodoBin n,tArbolBin A);
tArbolBin PodarHijoDrcha(nodoBin n,tArbolBin A);
