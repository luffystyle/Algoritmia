#define True  1
#define False 0

struct  node {
	void *value;
	struct node *next;
};

typedef struct node Node;

typedef struct node **Pila;	
	
Pila p_nula();
void apilar(void *elem, Pila p);
void desapilar(Pila p);
void *cima(Pila p);
int nula(Pila p);	
