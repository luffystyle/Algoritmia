#include <stdio.h>
#include <stdlib.h>
#include "pilas.h"

int main(void) {
	Pila p1,p2,p3;
	char *cad1="como";
	char *cad2="estas";
	char *cad3="hoy";
	char *cad4="muy";
	char *cad5="bien";
	char *cad6="gracias";
	int *num;
		
	p1 = p_nula();
	p2 = p_nula();
	p3 = p_nula();
	
	apilar(cad1,p1);	
	apilar(cad4,p2);
	apilar(cad2,p1);
	apilar(cad5,p2);
	apilar(cad3,p1);
	apilar(cad6,p2);
	
	num = (int *)malloc(sizeof(int));
	*num = 1;
	apilar(num,p3);
	num = (int *)malloc(sizeof(int));
	*num = 2;
	apilar(num,p3);
	num = (int *)malloc(sizeof(int));
	*num = 3;
	apilar(num,p3);
	
	printf("%s\n",(char *)cima(p1));
	desapilar(p1);
	printf("%s\n",(char *)cima(p1));
	desapilar(p1);
	printf("%s\n",(char *)cima(p1));
	desapilar(p1);
	
	if(nula(p1)) printf("La pila está vacía\n");
	
	printf("%s\n",(char *)cima(p2));
	desapilar(p2);
	printf("%s\n",(char *)cima(p2));
	desapilar(p2);
	printf("%s\n",(char *)cima(p2));
	desapilar(p2);
	
	if(nula(p2)) printf("La pila está vacía\n");
	
	num = (int *)cima(p3);
	printf("%d\n",*num);
	desapilar(p3);
	num = (int *)cima(p3);
	printf("%d\n",*num);
	desapilar(p3);
	num = (int *)cima(p3);
	printf("%d\n",*num);
	desapilar(p3);
	
	if(nula(p3)) printf("La pila está vacía\n");
	return 0;
}	
	
	
