#include <stdio.h>
#include <stdlib.h>
#include "pilas.h"


Pila p_nula() {
	Pila p;
	p = (Pila)malloc(sizeof(Node *));
	*p= NULL;
	return p;
}

void apilar(void *elem, Pila p) {
	Node *node;
	node = (Node *)malloc(sizeof(Node));
	node->value = elem;
	node->next = *p;
	*p = node;
}

void desapilar(Pila p) {
	Node *node;
	if(*p==NULL) {
		printf("Error: No se puede desapilar la pila vacia\n");
		exit(1);
	}	
	node = *p;
	*p = (*p)->next;
	free(node);
}

void *cima(Pila p) {
	if(*p==NULL) {
		printf("Error: No existe la cima de la pila vacia\n");
		exit(1);
	}
	return (*p)->value;
}

int nula(Pila p) {
	return (*p==NULL);
}		 
	
		
	
