#include <stdio.h>
#include <stdlib.h>
#include "arboles.h"


tArbolBin Crear0(tEtiqueta et){
  tArbolBin raiz;

  raiz = (tArbolBin)malloc(sizeof(struct tipoceldaBin));
  if (raiz==NULL) {
    printf("Memoria Insuficiente\n");
    exit(1);
  }
  raiz->padre = NODO_NULO;
  raiz->hizqda = NODO_NULO;
  raiz->hdrcha = NODO_NULO;
  raiz->etiqueta = et;
  return(raiz);
}

tArbolBin Crear2(tEtiqueta et,tArbolBin ti,tArbolBin td) {
  tArbolBin raiz; 
  
  raiz=(tArbolBin)malloc(sizeof(struct tipoceldaBin));
  if(!raiz){
    error("Memoria Insuficiente.");
  }
  raiz->padre=NULL;
  raiz->hizqda=ti;
  raiz->hdrcha=td;
  raiz->etiqueta=et;
  if(ti!=NULL)
    td->padre=raiz;

  return raiz;
}


nodoBin Padre(nodoBin n,tArbolBin A){   
  return(n->padre);
}


nodoBin Hderecha(nodoBin n,tArbolBin A){   
  return(n->hdrcha);
}


nodoBin Hizquierda(nodoBin n,tArbolBin A) {   
   return(n->hizqda);
}


tEtiqueta Etiqueta(nodoBin n,tArbolBin A) {  
  return(n->etiqueta);
}



nodoBin Raiz(tArbolBin A) {
  return A;
}

void Destruir(tArbolBin A) {
   
  if(A){
    Destruir(A->hizqda);
    Destruir(A->hdrcha);
    free(A);
  }
}

void InsertarHijoIzda(nodoBin n,tArbolBin ah,tArbolBin A) {
  Destruir(n->hizqda);
  n->hizqda=ah;
  ah->padre=n;
}


void InsertarHijoDrchaB(nodoBin n,tArbolBin ah,tArbolBin A) {
  Destruir(n->hdrcha);
  n->hdrcha=ah;
  ah->padre=n;
}


tArbolBin PodarHijoIzqda(nodoBin n,tArbolBin A) {
  tArbolBin Aaux;
   
  Aaux=n->hizqda;
  n->hizqda=BINARIO_VACIO;
  if(Aaux)
    Aaux->padre=BINARIO_VACIO;

  return Aaux;
}


tArbolBin PodarHijoDrcha(nodoBin n,tArbolBin A) {
  tArbolBin Aaux;
   
  Aaux=n->hdrcha;
  n->hdrcha=BINARIO_VACIO;
  if(Aaux)
    Aaux->padre=BINARIO_VACIO;

  return Aaux;
}
