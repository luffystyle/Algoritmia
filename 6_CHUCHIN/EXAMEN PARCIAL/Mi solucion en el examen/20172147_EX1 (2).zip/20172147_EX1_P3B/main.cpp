/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: aml
 *
 * Created on 19 de octubre de 2024, 09:07 AM
 */
#include <iostream>
#include <cstdlib>
#include <cmath>
using namespace std;

/*
 * 
 */
void cargaBin(int *cromo,int num,int cant){
    int i=0;
    int aux=num;
    //inicializo crmo
    for(int i=0;i<cant;i++)cromo[i]=0;
    while(1){
        if(aux==0)break;
        cromo[i]=aux%2;
        aux=aux/2;
        i++;
    }
}

void pasarAArregloLosDigitos(int *arrNumero,int numero,int nDig){
    int aux=numero;
    cout<<nDig<<endl;
    for(int i=nDig-1;i>=0;i--){
        arrNumero[i]=aux%10;
        aux=aux/10;
    }
    //
//    for(int i=0;i<nDig;i++)cout<<arrNumero[i]<<"-";
}

void posiblesSoluciones(int numero,int digitos,int &haySolu){
    int aux=numero;
    //paso a un arreglo los digitos del numero
    int arrNumero[digitos];
    pasarAArregloLosDigitos(arrNumero,numero,digitos);
    int cromo[digitos]{};
    int combinaciones=pow(2,digitos);
    int resultado;
    int digitoDentro;
    for(int i=0;i<combinaciones;i++){
        cargaBin(cromo,i,digitos);
        //recorremos cromo
        digitoDentro=0;
        for(int j=0;j<digitos;j++){
            if(cromo[j]==1)digitoDentro++;
        }
        
        int num1,num2;
        if(digitoDentro==2){//paso a un numero estos digitos y lo restante a otro
            int uno=0,dos=0;
            for(int k=0;k<digitos;k++){
                if(cromo[k]==1){
                    if(uno==0){
                        num1=arrNumero[k]*10;
                        uno++;
                    }
                    else num1+=arrNumero[k];
                        
                }
                else{
                    if(dos==0){
                        num2=arrNumero[k]*10;
                        dos++;
                    }
                    else num2+=arrNumero[k];
                }
            }
            cout<<num1<<"-"<<num2<<"R:";
            int resultado=num1*num2;
            cout<<resultado<<endl;
            if((num1*num2)==numero){
                cout<<"Aca"<<endl;
                haySolu=1;
                return;
            }
                
        }
    }
    
    

}

int calculoDigitos(int numero){
    int nDigitos=0;
    int aux=numero;
    while(1){
        if(aux==0)break;
        aux=aux/10;
        nDigitos++;
    }
    return nDigitos;
}

int esVampiro(int numero){
    int aux=numero;
    int digitos=calculoDigitos(aux);
    int haySolu=0;
    if(digitos%2==0){//si es par vemos los digitos de la multi
        posiblesSoluciones(aux,digitos,haySolu);
        cout<<haySolu<<endl;
//        cout<<"AAA";
        if(haySolu==1)return 1;
    }
    else{
        return 0;
    }
}

int main(int argc, char** argv) {
    //digitos par numero vampiro
    //vampiro(4digitos)=(2digitos)*(2digitos)
    //estos 2 digitos que se multiplcan todos deben ser diferentes}
    int numero=1260;
    int vampiro=esVampiro(numero);
    if(vampiro==1)cout<<"Número: "<<numero<<" es vampiro"<<endl;
    else cout<<"Numero no es vampiro"<<endl;
    return 0;
}

