/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: aml
 *
 * Created on 19 de octubre de 2024, 08:10 AM
 */

#include<iostream>
#include <cstdlib>
#include"Lista.h"
#include"funciones.h"
#define N 6
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    Lista arrListas[N];
    int n=6;
    
    for(int i=0;i<n;i++)construir(arrListas[i]);
    insertarAlFinal(arrListas,1,2);
    insertarAlFinal(arrListas,1,3);
    insertarAlFinal(arrListas,2,4);
    
    return 0;
}

