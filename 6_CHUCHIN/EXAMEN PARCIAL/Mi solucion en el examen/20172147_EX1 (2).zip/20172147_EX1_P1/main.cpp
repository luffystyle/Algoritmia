/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: aml
 *
 * Created on 19 de octubre de 2024, 10:11 AM
 */

#include <iostream>
#include <cstdlib>
#include "Pila.h"
#include "funcionesPila.h"
using namespace std;

/*
 * 
 */
int encontrarPilaAlta(int *alturas,Pila&pilaAux,int nPilas,int &pilasAlrededor){
    int aux,sig;
    int mayor=0;
    for(int i=0;i<nPilas-1;i++){
        aux=alturas[i];
        sig=alturas[i+1];
        if(aux>sig){
            if(esPilaVacia(pilaAux)==1)apilar(pilaAux,aux);
            else{
                
            }
        }
        else {
            if(esPilaVacia(pilaAux)==1)apilar(pilaAux,sig);
            else{
                int dentro=desapilar(pilaAux);
                if(dentro<sig){
//                    apilar(pilaAux,dentro);
                    apilar(pilaAux,sig);
                    mayor=i+1;
//                    pilasAlrededor++;
                }
                else{
                    apilar(pilaAux,dentro);
                }
            }
        }  
    }
    
    for(int i=0;i<nPilas;i++){
        if(alturas[mayor]>alturas[i])pilasAlrededor++;
    }
    return mayor;
}

int main(int argc, char** argv) {
//    int nPilas=4;
//    Pila fila[nPilas];
    //construyo pilas de acuerdo a la cantidad que hay en la fila
//    for(int i=0;i<nPilas;i++)construir(fila[i]);
    
    //alturas de cada pila
//    int alturas[nPilas]={1,3,6,4};  //sale para este caso
//    int nPilas=5;
//    int alturas[nPilas]={2,5,7,7,1}; //sale para este caso
//    int nPilas=14;
//    int alturas[nPilas]={1,7,2,7,3,4,3,2,1,7,2,1,7,3}; // no sale
    int nPilas=7;
    int alturas[nPilas]={6,2,5,4,5,1,6};//sale para este caso
    
    
    int posPilaAlta;
    Pila pilaAux;
    construir(pilaAux);
    int pilasAlrededor=0;
    posPilaAlta=encontrarPilaAlta(alturas,pilaAux,nPilas,pilasAlrededor);
    
    cout<<"Posicion="<<posPilaAlta<<", "<<pilasAlrededor;
    cout<<" pilas pequeñas alrededor"<<endl;
    
    return 0;
}

