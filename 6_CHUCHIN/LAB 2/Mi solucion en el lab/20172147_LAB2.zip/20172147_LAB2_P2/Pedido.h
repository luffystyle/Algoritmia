/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Pedido.h
 * Author: Luis Rios
 *
 * Created on 12 de octubre de 2024, 9:24
 */

#ifndef PEDIDO_H
#define PEDIDO_H

struct Pedido{
    char id[5];
    char complejidad;
    int disponibilidad;
    double distancia;
    int hora;
    int tiempo=0;
};

#endif /* PEDIDO_H */

