/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Luis Rios
 *
 * Created on 12 de octubre de 2024, 8:09
 */

#include <iostream>
#include <fstream>
#include <cstring>
#include "Lista.h"
#include "funciones.h"
#include "Pedido.h"
using namespace std;

/*
 * 
 */
void calculoTiempo(Lista&pedidos,int cantidad){
    Nodo *recorrido=pedidos.cabeza;
    for(int i=0;i<cantidad;i++){
        
    }
}

void cargarDatosLista(Lista &pedidos, ifstream &input, int nPedidos) {
    Nodo *nuevoNodo = nullptr; 
    Nodo *ultimoNodo = nullptr;
    int i = 0;
    char c;
    char id[5];
    Pedido data; 
    pedidos.cabeza = nullptr;
    pedidos.longitud = 0;
    while (true) {
        input.getline(id, 5, ',');
        if (input.eof()) break; 
        strcpy(data.id, id);
        input >> data.complejidad >>c>> data.disponibilidad >>c;
        input >> data.distancia >>c>> data.hora;
        input.get(); 
        nuevoNodo = new Nodo; 
        nuevoNodo->pedido = data; 
        nuevoNodo->siguiente = nullptr; 
        if (pedidos.cabeza == nullptr) {
            pedidos.cabeza = nuevoNodo;
        } else {
            ultimoNodo->siguiente = nuevoNodo;
        }
        ultimoNodo = nuevoNodo;
        pedidos.longitud++;
        cout << nuevoNodo->pedido.id << endl;
    }
    cout << "Pedidos:" << pedidos.longitud << endl;
}




int main(int argc, char** argv) {
    ifstream input("datos.txt",ios::in);
    if(!input.is_open()){
        cout<<"Error al leer archivo"<<endl;
        exit(1);
    }
    
    Lista pedidos;
    int n=5;
    
    cargarDatosLista(pedidos,input,n);
    imprime(pedidos);
    calculoTiempo(pedidos,n);
    return 0;
}

