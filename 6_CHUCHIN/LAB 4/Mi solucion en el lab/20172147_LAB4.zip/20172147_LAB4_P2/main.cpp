/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: aml
 *
 * Created on 30 de noviembre de 2024, 08:54 AM
 */

#include <iostream>
#include <cstdlib>
#include "ArbolBB.h"
#include "funcionesABB.h"
#include "funcionesAB.h"
#include "Pila.h"
#include "funcionesPila.h"

using namespace std;

/*
 * 
 */
//parte a
struct NodoArbol * crearNuevoNodoNew(struct NodoArbol * izquierda, int elemento,
                                     int cant,struct NodoArbol * derecha) {

    struct NodoArbol * nuevo = new struct NodoArbol;
    nuevo->derecha = derecha;
    nuevo->izquierda = izquierda;
    nuevo->elemento = elemento;
    nuevo->cantidad=cant;
    return nuevo;
}

void plantarArbolBinarioNew(struct NodoArbol *& raiz, 
                    struct NodoArbol * izquierda, int elemento,int cant,
                    struct NodoArbol * derecha){
    
    struct NodoArbol * nuevoNodo = crearNuevoNodoNew(izquierda, elemento,cant,derecha);
    raiz = nuevoNodo;
}

bool esNodoVacioNew(struct NodoArbol * raiz) {
    return raiz == nullptr;
}

void insertarRecursivoNew(struct NodoArbol *& raiz, int elemento,int cant){
    if(esNodoVacioNew(raiz))
        plantarArbolBinarioNew(raiz, nullptr, elemento,cant, nullptr);
    else
        if(raiz->elemento > elemento)
            insertarRecursivoNew(raiz->izquierda, elemento,cant);
        else
            if(raiz->elemento < elemento)
                insertarRecursivoNew(raiz->derecha, elemento,cant);
            else{
//                cout << "El elemento " << elemento << "Ya se encuentra en el árbol" << endl;
                raiz->cantidad=raiz->cantidad+cant;
            }
                
}

void ingresa_lote(struct ArbolBinarioBusqueda & arbol, int elemento,int cant){
    insertarRecursivoNew(arbol.arbolBinario.raiz, elemento,cant);
}


//parte b
struct NodoArbol *buscarNodo(struct NodoArbol*raiz,int elemento){
    while(1){
        if(esNodoVacio(raiz)==1)break;
        if(raiz->elemento==elemento)return raiz;
        if(raiz->elemento<elemento){//elemento del arbol es menor que elemento a buscar
            //voy derecha
            raiz=raiz->derecha;
        }
        else{
            if(raiz->elemento>elemento){
                //voy izquierda
                raiz=raiz->izquierda;
            }
        }
    }
//    return raiz;
}

void enOrdenIterativo(struct ArbolBinario arbol){
    Pila pila;
    construir(pila);
    struct NodoArbol*raiz=arbol.raiz;
    int valor=0;
    while(1){
        while(raiz){
            apilar(pila,raiz->elemento);
            raiz=raiz->izquierda;
        }
        if(esPilaVacia(pila)==1)break;
        valor=desapilar(pila);
        raiz=buscarNodo(arbol.raiz,valor);
        imprimirNodo(raiz);
        raiz=raiz->derecha;
    }
}

void enOrdenIterativo2(struct ArbolBinario arbol){
    Pila pila;
    construir(pila);
    struct NodoArbol*raiz=arbol.raiz;
    int valor=0;
    while(1){
        while(raiz){
            apilar(pila,raiz->elemento);
            raiz=raiz->derecha;
        }
        if(esPilaVacia(pila)==1)break;
        valor=desapilar(pila);
        raiz=buscarNodo(arbol.raiz,valor);
        imprimirNodo(raiz);
        raiz=raiz->izquierda;
    }
}

void mostrarReporte(ArbolBinarioBusqueda abb){
//    enOrdenIterativo(abb.arbolBinario);cout<<endl;
    enOrdenIterativo2(abb.arbolBinario);
}

int main(int argc, char** argv) {
    ArbolBinarioBusqueda abb;
    construir(abb);
    ingresa_lote(abb,2018,100);
    ingresa_lote(abb,2011,150);
    ingresa_lote(abb,2022,50);
    ingresa_lote(abb,2010,175);
    ingresa_lote(abb,2017,25);
    ingresa_lote(abb,2019,125);
    ingresa_lote(abb,2023,200);
    ingresa_lote(abb,2020,75);
    ingresa_lote(abb,2018,100);
//    enOrden(abb);
    
    //reporte stock
    cout<<endl<<"Reporte de stock:"<<endl;
    mostrarReporte(abb);
    return 0;
}

