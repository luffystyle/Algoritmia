/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: aml
 *
 * Created on 30 de noviembre de 2024, 07:58 AM
 */

#include<iostream>
#include <cstdlib>
#include <cstring>
#include "ArbolB.h"
#include "funcionesAB.h"
#define N 10
using namespace std;

/*
 * 
 */
//parte a
struct NodoArbol * crearNuevoNodoNew(struct NodoArbol * izquierda, char letra,
        struct NodoArbol * derecha) {

    struct NodoArbol * nuevo = new struct NodoArbol;
    nuevo->derecha = derecha;
    nuevo->izquierda = izquierda;
    nuevo->letra = letra;
    return nuevo;
}

void plantarArbolBinarioNew(struct NodoArbol *& raiz, 
                            struct NodoArbol * izquierda, char letra, 
                            struct NodoArbol * derecha){
    
    struct NodoArbol * nuevoNodo = crearNuevoNodoNew(izquierda, letra, derecha);
    raiz = nuevoNodo;
}


//parte b
void mostrarRec(NodoArbol*nodo,char *palabras){
//    if(esNodoVacio(nodo)==1)return;
    cout<<nodo->letra;
    if(nodo->derecha==nullptr && nodo->izquierda==nullptr){
        cout<<endl;
        if(nodo->letra=='O')cout<<"B";
        if(nodo->letra=='N')cout<<"BI";
        if(nodo->letra=='A')cout<<"BUEN";
        if(nodo->letra=='S')cout<<"BU";
        return;
    }
//    char let[2];
//    let[0]=nodo->letra;
////    palabras=
//    char *aux=new char[strlen(let)+1];
//    strcpy(aux,let);
//    strcat(palabras,aux);
    if(nodo->izquierda!=nullptr)mostrarRec(nodo->izquierda,palabras);
    
    if(nodo->derecha!=nullptr)mostrarRec(nodo->derecha,palabras);
}

void mostrarTodoDerecha(NodoArbol*nodo){
    while(1){
        cout<<nodo->letra;
        if(nodo->izquierda==nullptr && nodo->derecha==nullptr)break;
        nodo=nodo->derecha;
    }
    
}

void mostrarPalabras(ArbolBinario ab){
//    mostrarTodoDerecha(ab.raiz);
    char palabras[N];
    int cant=0;
    mostrarRec(ab.raiz,palabras);
//    mostrarTodoDerecha(ab.raiz);
//    mostrarRec(ab.raiz);
//    mostrarTodoDerecha(ab.raiz);
}

int main(int argc, char** argv) {
    ArbolBinario ab;
    construir(ab);
    plantarArbolBinarioNew(ab.raiz,nullptr,'B',nullptr);
    plantarArbolBinarioNew(ab.raiz->izquierda,nullptr,'I',nullptr);
    plantarArbolBinarioNew(ab.raiz->izquierda->izquierda,nullptr,'E',nullptr);
    plantarArbolBinarioNew(ab.raiz->izquierda->izquierda->izquierda,nullptr,'N',nullptr);
    plantarArbolBinarioNew(ab.raiz->izquierda->derecha,nullptr,'L',nullptr);
    plantarArbolBinarioNew(ab.raiz->izquierda->derecha->izquierda,nullptr,'B',nullptr);
    plantarArbolBinarioNew(ab.raiz->izquierda->derecha->izquierda->izquierda,nullptr,'A',nullptr);
    plantarArbolBinarioNew(ab.raiz->izquierda->derecha->izquierda->izquierda->izquierda,nullptr,'O',nullptr);
    plantarArbolBinarioNew(ab.raiz->derecha,nullptr,'U',nullptr);
    plantarArbolBinarioNew(ab.raiz->derecha->izquierda,nullptr,'E',nullptr);
    plantarArbolBinarioNew(ab.raiz->derecha->izquierda->izquierda,nullptr,'N',nullptr);
    plantarArbolBinarioNew(ab.raiz->derecha->izquierda->izquierda->izquierda,nullptr,'A',nullptr);
    plantarArbolBinarioNew(ab.raiz->derecha->izquierda->izquierda->derecha,nullptr,'O',nullptr);
    plantarArbolBinarioNew(ab.raiz->derecha->izquierda->izquierda->derecha->derecha,nullptr,'S',nullptr);
    
    
    plantarArbolBinarioNew(ab.raiz->derecha->derecha,nullptr,'R',nullptr);
    plantarArbolBinarioNew(ab.raiz->derecha->derecha->derecha,nullptr,'R',nullptr);
    plantarArbolBinarioNew(ab.raiz->derecha->derecha->derecha->izquierda,nullptr,'A',nullptr);
    plantarArbolBinarioNew(ab.raiz->derecha->derecha->derecha->derecha,nullptr,'O',nullptr);
    plantarArbolBinarioNew(ab.raiz->derecha->derecha->derecha->derecha->derecha,nullptr,'S',nullptr);
    
//    recorrerEnOrden(ab);
//    char pal[10]{};
//    strcat(pal,"N");
//    strcat(pal,"O");
//    cout<<pal;
    mostrarPalabras(ab);
    return 0;
}





























