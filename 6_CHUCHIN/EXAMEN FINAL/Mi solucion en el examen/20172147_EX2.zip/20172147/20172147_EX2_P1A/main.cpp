/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: alulab14
 *
 * Created on 7 de diciembre de 2024, 08:05 AM
 */
#include <iostream>
#include <cstdlib>
#define N 10
using namespace std;

/*
 * 
 */
//parte i)
int buscarLote(int *arr,int ini,int fin,int cantidadABuscar){
    if(ini>fin)return -1;
    int medio=(ini+fin)/2;
    if(arr[medio]==cantidadABuscar){
        if(arr[medio]==arr[medio-1])return medio-1;
         return medio;
    }
    if(arr[medio]>cantidadABuscar)return buscarLote(arr,ini,medio-1,cantidadABuscar);
    else return buscarLote(arr,medio+1,fin,cantidadABuscar);
}

//parte ii)
int buscarLote2(int *arr,int ini,int fin,int cantidadABuscar){
    if(ini>fin)return -1;
    int medio=(ini+fin)/2;
    if(arr[medio]==cantidadABuscar){
        if(arr[medio]==arr[medio+1] && arr[medio+1]==arr[medio+2])return medio+2;
        else if(arr[medio]==arr[medio+1])return medio+1;
        return medio;

    }
    if(arr[medio]>cantidadABuscar){
        return buscarLote2(arr,ini,medio-1,cantidadABuscar);
    }
    else {
        return buscarLote2(arr,medio+1,fin,cantidadABuscar);
    }
        
}

int main(int argc, char** argv) {
    int lote[N]={15872,15865,15866,14357,14365,14368,14370,19258,19260};
    int cantidad[N]={3,4,4,6,6,6,6,8,8};
    int cantidad2[N]={3,4,4,6,6,6,6,8,8};
    int n=9;
    //busca inicio y busca fin
    //en uno encuentras el indice y en el otro el fin
    int cantidadABuscar=8;
    int indice=buscarLote(cantidad2,0,n-1,cantidadABuscar);
    cout<<"Para encontrar los lotes de "<<cantidadABuscar<<" productos: "<<endl;
    cout<<"Lote Inicial: "<<lote[indice]<<endl;
    
    //parte ii)
    
    int cantidadABuscar2=cantidadABuscar;
    int indice2=buscarLote2(cantidad,0,n-1,cantidadABuscar2);
    cout<<"Lote final: "<<lote[indice2]<<endl;
    return 0;
}

