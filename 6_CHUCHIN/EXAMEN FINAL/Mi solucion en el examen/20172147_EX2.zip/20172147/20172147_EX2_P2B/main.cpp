/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: alulab14
 *
 * Created on 7 de diciembre de 2024, 09:01 AM
 */
#include "ArbolBB.h"
#include "funcionesABB.h"
#include "funcionesAB.h"
#include <cstdlib>
#include <iostream>
#include <cstring>
//platos es un ordenamiento pero no es un merge, es un quicksort
//igual las listas no es necesario esta demas
using namespace std;

/*
 * 
 */

struct NodoArbol * crearNuevoNodoNew(struct NodoArbol * izquierda, int elemento,
        char letra,
        struct NodoArbol * derecha) {

    struct NodoArbol * nuevo = new struct NodoArbol;
    nuevo->derecha = derecha;
    nuevo->izquierda = izquierda;
    nuevo->elemento = elemento;
    nuevo->letra=letra;
    return nuevo;
}

void plantarArbolBinarioNew(struct NodoArbol *& raiz, 
                    struct NodoArbol * izquierda, int elemento,char letra, 
                    struct NodoArbol * derecha){
    
    struct NodoArbol * nuevoNodo = crearNuevoNodoNew(izquierda, elemento,letra, derecha);
    raiz = nuevoNodo;
}

void insertarRecursivoNew(struct NodoArbol *& raiz, int elemento,char letra){
    if(esNodoVacio(raiz))
        plantarArbolBinarioNew(raiz, nullptr, elemento,letra, nullptr);
    else
        if(raiz->elemento > elemento)
            insertarRecursivoNew(raiz->izquierda, elemento,letra);
        else
            if(raiz->elemento < elemento)
                insertarRecursivoNew(raiz->derecha, elemento,letra);
            else
                cout << "El elemento " << elemento << "Ya se encuentra en el árbol" << endl;
}

void insertarNew(struct ArbolBinarioBusqueda & arbol, int elemento,char letra){
    insertarRecursivoNew(arbol.arbolBinario.raiz, elemento,letra);
}

void recorrerEnOrdenRecursivoNew(struct NodoArbol * nodo,string &contra){
    if (not esNodoVacio(nodo)){
        recorrerEnOrdenRecursivoNew(nodo->izquierda,contra);
        contra+=nodo->letra;
        recorrerEnOrdenRecursivoNew(nodo->derecha,contra);
    }
}

void recorrerEnOrdenNew(const struct ArbolBinario & arbol,string &contra){
    recorrerEnOrdenRecursivoNew(arbol.raiz,contra);
}


void obtenerContra(ArbolBinarioBusqueda abb,string &contra){
    recorrerEnOrdenNew(abb.arbolBinario,contra);
}

void recorreRec(struct NodoArbol * nodo,int &longitud){
    if (not esNodoVacio(nodo)){
        recorreRec(nodo->izquierda,longitud);
        longitud+=1;
        recorreRec(nodo->derecha,longitud);
        
    }
}

void recorre(ArbolBinario arbol,int &longitud){
    recorreRec(arbol.raiz,longitud);
}

int verificaTamcontrasenhiaArbol(ArbolBinarioBusqueda abb,char *&contraArbol,int tamIngresado){
    int longitud=0;
    recorre(abb.arbolBinario,longitud);
    contraArbol=new char[longitud+1]{};
//    cout<<longitud<<endl;
    if(tamIngresado!=longitud)return 0;
    else return 1;
}

void recorreRec3(struct NodoArbol * nodo,int &igual,string &contraIngresada){
    if (not esNodoVacio(nodo)){
        char letra=contraIngresada.front();
        cout<<contraIngresada[0]<<endl;
//        contraIngresada.push_back();
        if(letra==nodo->letra){
            cout<<"f:"<<letra<<nodo->letra<<endl;
            igual=1;
        }
            
//        else return ;
        recorreRec3(nodo->izquierda,igual,contraIngresada);
//        letra=contraIngresada.front();
//        if(letra==nodo->letra){
//            cout<<letra<<nodo->letra<<endl;
//            igual=1;
//        }
        recorreRec3(nodo->derecha,igual,contraIngresada);
        
    }
}

void obtenerContraNew(ArbolBinario ab,string &contra,int &igual,string contraIngresada){
    recorrerEnOrdenNew(ab,contra);
    igual=contra.compare(contraIngresada);
//    cout<<igual<<endl;
}

int recorre2(ArbolBinario ab,char *contraArbol,string contraIngresada){
    
    
    int igual=0;
    string contraDentro;
    obtenerContraNew(ab,contraDentro,igual,contraIngresada);
    
//    recorreRec3(ab.raiz,igual,contraIngresada);
    
    return igual;
}

int verificaIgualcontrasenhiaArbol(ArbolBinarioBusqueda abb,char *contraArbol,
                                   string contraIngresada){
    int longitud=0;
    
    return recorre2(abb.arbolBinario,contraArbol,contraIngresada);
//    contraArbol=new char[longitud+1]{};
//    cout<<longitud<<endl;
    
//    if(tamIngresado!=longitud)return 0;
//    else return 1;
}

int main(int argc, char** argv) {
    ArbolBinarioBusqueda abb;
    construir(abb);
    insertarNew(abb,4,'P');
    insertarNew(abb,2,'U');
    insertarNew(abb,6,'0');
    insertarNew(abb,1,'P');
    insertarNew(abb,3,'C');
    insertarNew(abb,5,'2');
    insertarNew(abb,7,'2');
    insertarNew(abb,8,'4');

    int intentos;
    cout<<"Ingrese el numero maximo de intentos: ";
    cin>>intentos;
    string contraIngresada;
    for(int i=0;i<intentos;i++){
        cout<<"Intento "<<i+1<<"/"<<intentos<<". ";
        cout<<"Ingrese la contrasenia: ";
        cin>>contraIngresada;
        int tamIngre=contraIngresada.size();
        char *contraArbol;
        int tamIgual;
        tamIgual=verificaTamcontrasenhiaArbol(abb,contraArbol,tamIngre);
        int tamContra=strlen(contraArbol);
        if(tamIgual==0){
            cout<<"Longitud incorrecta. Intento fallido."<<endl;
        }
        else{
            int igual=verificaIgualcontrasenhiaArbol(abb,contraArbol,contraIngresada);
            if(igual==0){
                cout<<"Acceso concedido"<<endl;
            }
            else{
                cout<<"Contrasenhia incorrecta. Intento fallido. "<<endl;
            }

        }
        
    }
    return 0;
}

