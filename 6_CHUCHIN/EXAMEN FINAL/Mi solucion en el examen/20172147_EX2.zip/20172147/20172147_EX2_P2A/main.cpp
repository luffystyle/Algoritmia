/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: alulab14
 *
 * Created on 7 de diciembre de 2024, 09:26 AM
 */
#include "ArbolB.h"
#include "funcionesAB.h"
#include <iostream>
#include <cstdlib>

using namespace std;

/*
 * 
 */

struct NodoArbol * crearNuevoNodoNew(struct NodoArbol * izquierda, int elemento,
        struct NodoArbol * derecha) {

    struct NodoArbol * nuevo = new struct NodoArbol;
    nuevo->derecha = derecha;
    nuevo->izquierda = izquierda;
    nuevo->elemento = elemento;
    return nuevo;
}

void plantarArbolBinarioNew(struct NodoArbol *& raiz, 
                            struct NodoArbol * izquierda, int elemento, 
                            struct NodoArbol * derecha){
    
    struct NodoArbol * nuevoNodo = crearNuevoNodoNew(izquierda, elemento, derecha);
    raiz = nuevoNodo;
}

int  recorreRec(NodoArbol*nodo,int numero,int cuenta){
//    cuenta+=(2*nodo->elemento);
    if(esNodoVacio(nodo)==1)return 0;
    if(nodo->derecha==nullptr && nodo->izquierda==nullptr){
        if(cuenta==numero)return 1;
    }
    return recorreRec(nodo->izquierda,numero,cuenta)+
           recorreRec(nodo->derecha,numero,cuenta);
}

void  recorre(ArbolBinario ab,int numero){
    if(esNodoVacio(ab.raiz)==1)return;
    int cuenta=0;
    int cant;
    cant =recorreRec(ab.raiz,numero,cuenta);
    cout<<numero<<"   :"<<cant<<endl;
}

int main(int argc, char** argv) {
    ArbolBinario ab;
    construir(ab);
    
    plantarArbolBinarioNew(ab.raiz,nullptr,5,nullptr);
    //nivel 1
    plantarArbolBinarioNew(ab.raiz->izquierda,nullptr,1,nullptr);
    plantarArbolBinarioNew(ab.raiz->derecha,nullptr,0,nullptr);
    //nivel 2
    plantarArbolBinarioNew(ab.raiz->izquierda->izquierda,nullptr,1,nullptr);
    plantarArbolBinarioNew(ab.raiz->izquierda->derecha,nullptr,0,nullptr);
    //nivel 3
    plantarArbolBinarioNew(ab.raiz->izquierda->izquierda->izquierda,nullptr,1,nullptr);
    plantarArbolBinarioNew(ab.raiz->izquierda->derecha->izquierda,nullptr,1,nullptr);
    plantarArbolBinarioNew(ab.raiz->izquierda->derecha->derecha,nullptr,0,nullptr);
    //nivel 4
    plantarArbolBinarioNew(ab.raiz->izquierda->izquierda->izquierda->derecha,nullptr,0,nullptr);
    plantarArbolBinarioNew(ab.raiz->izquierda->derecha->derecha->izquierda,nullptr,1,nullptr);
   
    
    int numero=14;
    recorre(ab,numero);
    
    
//    recorrerEnOrden(ab);

    
    
//    plantarArbolBinario(ab.raiz->izquierda,nullptr,1,nullptr);
//    plantarArbolBinario(ab.raiz->derecha,nullptr,0,nullptr);
//    recorrerEnOrden(ab);
    return 0;
}

