/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: aml
 *
 * Created on 14 de septiembre de 2024, 08:07 AM
 */

#include <cstdlib>
#include<iostream>
#include<cmath>
#include<cstring>
using namespace std;

/*
 * 
 */

void cargaCromo(int comb,int *cromo){
    for(int i=0;i<8;i++){
        if(comb==0)break;
        cromo[i]=comb%4;
        comb=comb/4;
    }
}

int main(int argc, char** argv) {
    char letrasFabricadas[8]={'G','A','L','A','O','G','L','M'};
    int palabras=10,nletras;
    int combinLetras1,combinLetras2,combinLetras3,combinLetras4;
    int comb1,comb2,comb3,comb4;
//    char palabra1[8]={'G','O','L'};
//    char palabra2[8]={'G','A','L','A'};
//    char palabra3[8]={'A','L','A'};
//    char palabra4[8]={'L','O','M','A'};
    
    
    //INGRESO DE DATOS
    char palabra1[8]{};
    char palabra2[8]{};
    char palabra3[8]{};
    char palabra4[8]{};
    char letra;
    cout<<"Digite cuantas palabras empaquetara:";
    cin>>palabras;
    //Ingreso de datos
    for(int i=0;i<palabras;i++){
        cout<<"Ingrese cuantas letras tendra la palabra "<<i+1<<"(max 8):";
        cin>>nletras;
        for(int j=0;j<nletras;j++){
            cout<<"Ingrese letra "<<j+1<<": ";
            cin>>letra;
            if(i==0)palabra1[j]=letra;
            if(i==1)palabra2[j]=letra;
            if(i==2)palabra3[j]=letra;
            if(i==3)palabra4[j]=letra;
        }
        
    }
    
  
    
    /*//sin cromo
    for(int i=0;i<4;i++){//palabras
        if(i==0){//acumular palabra1
            int acumEncontradas=0;
            combinLetras1=0;
            for(int j=0;j<8;j++){ //recorre cada letra de la palabra
                for(int k=0;k<8;k++){//recorremos tablero de letras
                    if(palabra1[j]==letrasFabricadas[k]){
                        acumEncontradas++;
                        break;
                    }   
                }
                if(acumEncontradas==3){
                        combinLetras1++;
                        break;
                }   
            }
            comb1=combinLetras1;
        }
        if(i==1){//acumular palabra1
            int acumEncontradas=0;
            combinLetras2=0;
            for(int j=0;j<8;j++){ //recorre cada letra de la palabra
                for(int k=0;k<8;k++){//recorremos tablero de letras
                    if(palabra2[j]==letrasFabricadas[k]){
                        acumEncontradas++;
                        break;
                    }   
                }
                if(acumEncontradas==3){
                        combinLetras2++;
                        break;
                }   
            }
            comb2=combinLetras1;
        }
        if(i==2){//acumular palabra1
            int acumEncontradas=0;
            combinLetras3=0;
            for(int j=0;j<8;j++){ //recorre cada letra de la palabra
                for(int k=0;k<8;k++){//recorremos tablero de letras
                    if(palabra3[j]==letrasFabricadas[k]){
                        acumEncontradas++;
                        break;
                    }   
                }
                if(acumEncontradas==3){
                        combinLetras3++;
                        break;
                }   
            }
            comb3=combinLetras3;
        }
        if(i==3){//acumular palabra1
            int acumEncontradas=0;
            combinLetras4=0;
            for(int j=0;j<8;j++){ //recorre cada letra de la palabra
                for(int k=0;k<8;k++){//recorremos tablero de letras
                    if(palabra4[j]==letrasFabricadas[k]){
                        acumEncontradas++;
                        break;
                    }   
                }
                if(acumEncontradas==3){
                        combinLetras4++;
                        break;
                }   
            }
            comb4=combinLetras4;
        }
    }*/
    
    
    
    
    
    
    
    
    //con cromo
    int combinaciones=pow(4,8);
    int cromo[8]{};
    int cont1=0,contf2=0,contf3=0,contf4=0;
    for(int i=0;i<combinaciones;i++){
        cargaCromo(i,cromo);
        char aux1[8],aux2[8],aux3[8],aux4[8];
        strcpy(aux1,palabra1);
        strcpy(aux2,palabra1);
        strcpy(aux3,palabra1);
        strcpy(aux4,palabra1);
        int cont=0,cont2=0,cont3=0,cont4=0;
        for(int j=0;j<8;j++){//recorremos cromo
            if(cromo[j]==1){
                //comparamos en palabra 1
                for(int k=0;k<8;k++){//recorremos palabra1
                    if(letrasFabricadas[j]==aux1[k]){
                        aux1[k]='-';
                        cont++;
                        break;
                    }
                }
                
            }
            if(cromo[j]==2){
                //comparamos en palabra 1
                for(int k=0;k<8;k++){//recorremos palabra1
                    if(letrasFabricadas[j]==aux2[k]){
                        aux2[k]='-';
                        cont2++;
                        break;
                    }
                }
                
            }
            if(cromo[j]==3){
                //comparamos en palabra 1
                for(int k=0;k<8;k++){//recorremos palabra1
                    if(letrasFabricadas[j]==aux3[k]){
                        aux3[k]='-';
                        cont3++;
                        break;
                    }
                }
                
            }
            if(cromo[j]==4){
                //comparamos en palabra 1
                for(int k=0;k<8;k++){//recorremos palabra1
                    if(letrasFabricadas[j]==aux4[k]){
                        aux4[k]='-';
                        cont4++;
                        break;
                    }
                }
                
            }
        }
        if(cont==3)cont1++;
        if(cont2==4)contf2++;
        if(cont3==3)contf3++;
        if(cont4==4)contf4++;
    }
     
    
    //impresion
    for(int i=0;i<4;i++){
        if(i==0){
            cout<<"La palabra ";
            for(int j=0;j<8;j++)cout<<palabra1[j];
            cout<<" tiene "<<cont1<<" combinaciones de Letras"<<endl;
        }
        if(i==1){
            cout<<"La palabra ";
            for(int j=0;j<8;j++)cout<<palabra2[j];
            cout<<" tiene "<<contf2<<" combinaciones de Letras"<<endl;
        }
        if(i==2){
            cout<<"La palabra ";
            for(int j=0;j<8;j++)cout<<palabra3[j];
            cout<<" tiene "<<contf3<<" combinaciones de Letras"<<endl;
        }
        if(i==3){
            cout<<"La palabra ";
            for(int j=0;j<8;j++)cout<<palabra4[j];
            cout<<" tiene "<<contf4<<" combinaciones de Letras"<<endl;
        }
        
    }
    return 0;
}

