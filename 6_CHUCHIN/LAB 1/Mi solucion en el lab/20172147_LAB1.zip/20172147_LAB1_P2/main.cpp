/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: aml
 *
 * Created on 14 de septiembre de 2024, 09:42 AM
 */

#include <cstdlib>
#include <iostream>
#define N 5
#define M 5
#define cantMax 15
using namespace std;

/*
 * 
 */

void imprimeFila(int tablero[][M],int posX,int posY,int n,int m){
    if(posX==N)return;
    if(posX>0 && posY==M-1){
        cout<<tablero[posX][posY]<<" ";
        imprimeFila(tablero,posX+1,posY,n,m);
    }
}
int main(int argc, char** argv) {
    int tablero[N][M]={{4,3,6,8,7},
                       {6,3,8,4,10},
                       {2,15,1,2,13},
                       {5,1,10,11,2},
                       {10,4,7,9,4}};
    
    int posX=0,posY=0;
    int n=5,m=5;
    imprimeFila(tablero,posX,posY,n,m);
    return 0;
}

