/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: aml
 *
 * Created on 14 de diciembre de 2024, 08:15 AM
 */
#include "ArbolBB.h"
#include "funcionesABB.h"
#include "funcionesAB.h"
#include <iostream>
#include <cstdlib>
#define D 7
#define T 4

using namespace std;

/*
 * elemento es el dia 
 */

struct NodoArbol * crearNuevoNodoNew(struct NodoArbol * izquierda, int elemento,
                        int turno,int cantidad,struct NodoArbol * derecha) {

    struct NodoArbol * nuevo = new struct NodoArbol;
    nuevo->derecha = derecha;
    nuevo->izquierda = izquierda;
    nuevo->elemento = elemento;
    nuevo->turno=turno;
    nuevo->cantidad=cantidad;
    return nuevo;
}

void plantarArbolBinarioNew(struct NodoArbol *& raiz, 
                    struct NodoArbol * izquierda, int elemento, 
                    int turno,int cantidad,struct NodoArbol * derecha){
    
    struct NodoArbol * nuevoNodo = crearNuevoNodoNew(izquierda, elemento,
                                                     turno,cantidad, derecha);
    raiz = nuevoNodo;
}

void insertarRecursivoNew(struct NodoArbol *& raiz, int elemento,
                       int turno,int cantidad){
    if(esNodoVacio(raiz)){
        
        plantarArbolBinarioNew(raiz, nullptr, elemento
                               ,turno,cantidad, nullptr);
    }
    else
//        if(raiz->elemento > elemento)
//            insertarRecursivoNew(raiz->izquierda, elemento,turno,cantidad);
//        else
//            if(raiz->elemento < elemento)
//                insertarRecursivoNew(raiz->derecha, elemento,turno,cantidad);
//            else
//                cout << "El elemento " << elemento << "Ya se encuentra en el árbol" << endl;
        if(raiz->elemento > elemento){
            insertarRecursivoNew(raiz->izquierda, elemento,turno,cantidad);
        }   
        else{
             if(raiz->elemento < elemento){
                 insertarRecursivoNew(raiz->derecha, elemento,turno,cantidad);
             }
            else{
//                 cout<<turno<<endl;
                 if(turno<raiz->turno){
                     insertarRecursivoNew(raiz->izquierda, elemento,turno,cantidad);
                 }
                 else{
                     insertarRecursivoNew(raiz->derecha, elemento,turno,cantidad);
                 }
//                 cout << "El elemento " << elemento << "Ya se encuentra en el árbol" << endl;
            }
        }       
           
}

void recorrerEnOrdenRecursivoNew(struct NodoArbol * nodo,int *nodos,int &i,
                                int *turnos,int *cantidad){
    if (not esNodoVacio(nodo)){
        recorrerEnOrdenRecursivoNew(nodo->izquierda,nodos,i,turnos,cantidad);
//        imprimirNodo(nodo);
        nodos[i]=nodo->elemento;
        turnos[i]=nodo->turno;
        cantidad[i]=nodo->cantidad;
        i++;
        recorrerEnOrdenRecursivoNew(nodo->derecha,nodos,i,turnos,cantidad);
    }
}

void recorrerEnOrdenNew(const struct ArbolBinario & arbol,int *nodos,int &i,
                        int *turnos,int *cantidad){
    recorrerEnOrdenRecursivoNew(arbol.raiz,nodos,i,turnos,cantidad);
}


void recorreEnOrdenCargaArr(const struct ArbolBinarioBusqueda & arbol,
                            int *nodos,int &i,int *turnos,int *cantidad){
    recorrerEnOrdenNew(arbol.arbolBinario,nodos,i,turnos,cantidad);
}

//struct NodoArbol * crearNuevoNodoNew(struct NodoArbol * izquierda, int elemento,
//                                     int turno,int cantidad,struct NodoArbol * derecha) {
//
//    struct NodoArbol * nuevo = new struct NodoArbol;
//    nuevo->derecha = derecha;
//    nuevo->izquierda = izquierda;
//    nuevo->elemento = elemento;
//    nuevo->cantidad=cantidad;
//    nuevo->turno=turno;
//    return nuevo;
//}

NodoArbol *construirArbolBalanceado(int *nodos,int ini,int fin,int *turnos,
                                    int *cantidad){
    if(ini>fin)return nullptr;
    int medio=(ini+fin)/2;
    NodoArbol*nodo=crearNuevoNodoNew(nullptr,nodos[medio],turnos[medio],
                                     cantidad[medio],nullptr);
    nodo->izquierda=construirArbolBalanceado(nodos,ini,medio-1,turnos,cantidad);
    nodo->derecha=construirArbolBalanceado(nodos,medio+1,fin,turnos,cantidad);
}

void equilibrarArbol(ArbolBinarioBusqueda&arbol){
    int numNodos=numeroNodos(arbol.arbolBinario);
    int nodos[numNodos],i=0;
    int turnos[numNodos],cantidad[numNodos];
    recorreEnOrdenCargaArr(arbol,nodos,i,turnos,cantidad);
    destruirArbolBinario(arbol.arbolBinario);
    arbol.arbolBinario.raiz=construirArbolBalanceado(nodos,0,numNodos-1,turnos,cantidad);
}


void insertardiaturno(struct ArbolBinarioBusqueda & arbol,int elemento,
                      int turno,int cantidad){
    insertarRecursivoNew(arbol.arbolBinario.raiz,elemento,turno,cantidad);
    int equilibrado=esEquilibrado(arbol.arbolBinario);
    if(equilibrado!=1){
        equilibrarArbol(arbol);
//        cout<<turno<<" es:"<<equilibrado<<endl;
//        recorrerPostOrden(arbol.arbolBinario);cout<<endl;
        //equilibramos
    }
}

int main(int argc, char** argv) {
    ArbolBinarioBusqueda abb;
    construir(abb);
    int datos[T][D]={{100,103,100,101,100,99,100},
                      {100,102,102,92,99,100,98},
                      {100,100,102,100,100,101,100},
                      {98,96,93,99,100,102,95}};
    //lune 0 martes 1 miercoles 2 jueves 3 viernes 4 abado5 domin 6
    for(int i=0;i<D;i++){
        for(int j=0;j<T;j++){
            insertardiaturno(abb,i,j+1,datos[j][i]);
        }
    }
    
    
    
    cout<<endl;
    int equili=esEquilibrado(abb.arbolBinario);
    cout<<equili<<endl;
    if(equili==1){
        cout<<"Arbol si esta equilibrado: ";
        enOrden(abb);cout<<endl;
    }
//    insertardiaturno(abb,0,1,100);
//    insertardiaturno(abb,0,1,100);
    return 0;
}

