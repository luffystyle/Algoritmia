/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: aml
 *
 * Created on 14 de diciembre de 2024, 09:18 AM
 */

#include "ArbolBB.h"
#include "funcionesABB.h"
#include "funcionesAB.h"
#include <iostream>
#include <cstdlib>
#define D 7
#define T 4
#define N 28

using namespace std;

/*
 * elemento es el dia 
 */

struct NodoArbol * crearNuevoNodoNew(struct NodoArbol * izquierda, int elemento,
                        struct NodoArbol * derecha) {

    struct NodoArbol * nuevo = new struct NodoArbol;
    nuevo->derecha = derecha;
    nuevo->izquierda = izquierda;
    nuevo->elemento = elemento;
//    nuevo->turno=turno;
//    nuevo->cantidad=cantidad;
    return nuevo;
}

void plantarArbolBinarioNew(struct NodoArbol *& raiz, 
                    struct NodoArbol * izquierda, int elemento, 
                    struct NodoArbol * derecha){
    
    struct NodoArbol * nuevoNodo = crearNuevoNodoNew(izquierda, elemento,
                                                     derecha);
    raiz = nuevoNodo;
}

void insertarRecursivoNew(struct NodoArbol *& raiz, int elemento){
    if(esNodoVacio(raiz)){
        plantarArbolBinarioNew(raiz, nullptr, elemento,nullptr);
    }
    else
//        if(raiz->elemento > elemento)
//            insertarRecursivoNew(raiz->izquierda, elemento,turno,cantidad);
//        else
//            if(raiz->elemento < elemento)
//                insertarRecursivoNew(raiz->derecha, elemento,turno,cantidad);
//            else
//                cout << "El elemento " << elemento << "Ya se encuentra en el árbol" << endl;
        if(raiz->elemento >= elemento){
            insertarRecursivoNew(raiz->izquierda, elemento);
        }   
        else{
             if(raiz->elemento < elemento){
                 insertarRecursivoNew(raiz->derecha, elemento);
             }
            else{
//                 cout<<turno<<endl;
//                 insertarRecursivoNew(raiz->izquierda, elemento);
                 cout << "El elemento " << elemento << "Ya se encuentra en el árbol" << endl;
            }
        }       
           
}

void recorrerEnOrdenRecursivoNew(struct NodoArbol * nodo,int *nodos,int &i){
    if (not esNodoVacio(nodo)){
        recorrerEnOrdenRecursivoNew(nodo->izquierda,nodos,i);
//        imprimirNodo(nodo);
        nodos[i]=nodo->elemento;
        i++;
        recorrerEnOrdenRecursivoNew(nodo->derecha,nodos,i);
    }
}

void recorrerEnOrdenNew(const struct ArbolBinario & arbol,int *nodos,int &i){
    recorrerEnOrdenRecursivoNew(arbol.raiz,nodos,i);
}


void recorreEnOrdenCargaArr(const struct ArbolBinarioBusqueda & arbol,
                            int *nodos,int &i){
    recorrerEnOrdenNew(arbol.arbolBinario,nodos,i);
}



NodoArbol *construirArbolBalanceado(int *nodos,int ini,int fin){
    if(ini>fin)return nullptr;
    int medio=(ini+fin)/2;
    NodoArbol*nodo=crearNuevoNodoNew(nullptr,nodos[medio],nullptr);
    nodo->izquierda=construirArbolBalanceado(nodos,ini,medio-1);
    nodo->derecha=construirArbolBalanceado(nodos,medio+1,fin);
}

void equilibrarArbol(ArbolBinarioBusqueda&arbol){
    int numNodos=numeroNodos(arbol.arbolBinario);
    int nodos[numNodos],i=0;
    recorreEnOrdenCargaArr(arbol,nodos,i);
    destruirArbolBinario(arbol.arbolBinario);
    arbol.arbolBinario.raiz=construirArbolBalanceado(nodos,0,numNodos-1);
}


void insertarcantidad(struct ArbolBinarioBusqueda & arbol,int elemento){
    insertarRecursivoNew(arbol.arbolBinario.raiz,elemento);
    int equilibrado=esEquilibrado(arbol.arbolBinario);
    if(equilibrado!=1){
        equilibrarArbol(arbol);
//        cout<<turno<<" es:"<<equilibrado<<endl;
//        recorrerPostOrden(arbol.arbolBinario);cout<<endl;
        //equilibramos
    }
}


void merge(int arr[N], int inicio, int medio, int fin){
    int aux[N], p, q, m;
    /*Aqui estamos mezclando los dos arreglos*/
    for (p=inicio, q=medio+1, m=inicio; p<=medio && q<=fin; m++){
        if (arr[p]<arr[q]){
            aux[m] = arr[p];
            p++;
        }
        else{
            aux[m] = arr[q];
            q++;
        }
    }

    while (p<=medio){
        aux[m] = arr[p];
        p++;
        m++;
    }
    while (q<=fin){
        aux[m] = arr[q];
        q++;
        m++;
    }
    
    for (int i=inicio; i<=fin; i++){
        arr[i] = aux[i];
    }
}

void mergeSort(int arr[N],int inicio,int fin){
    if (inicio==fin){
        return ;
    }
    int medio = (inicio+fin)/2;
    mergeSort(arr,inicio,medio);
    mergeSort(arr,medio+1,fin);
    merge(arr,inicio,medio,fin);
}


int main(int argc, char** argv) {
    ArbolBinarioBusqueda abb;
    construir(abb);
    int datos[T][D]={{100,103,100,101,100,99,100},
                      {100,102,102,92,99,100,98},
                      {100,100,102,100,100,101,100},
                      {98,96,93,99,100,102,95}};
    //lune 0 martes 1 miercoles 2 jueves 3 viernes 4 abado5 domin 6
    int arr[N],pos=0;
    for(int i=0;i<D;i++){
        for(int j=0;j<T;j++){
            arr[pos]=datos[j][i];
            pos++;
//            insertarcantidad(abb,datos[j][i]);
            
        }
    }
    
    mergeSort(arr,0,pos-1);
    
    //generamos el arbol equilibrado
    for(int i=0;i<N;i++){
//        cout<<arr[i]<<" ";
//        insertar(abb,arr[i]);
        insertarcantidad(abb,arr[i]);
    }
//    for(int i=0;i<28;i++)cout<<arr[i]<<" ";
//    cout<<endl;
    int equili=esEquilibrado(abb.arbolBinario);
//    cout<<equili<<endl;
//    cout<<endl;enOrden(abb);
    if(equili==1){
        cout<<"Arbol si esta equilibrado: ";
        enOrden(abb);cout<<endl;
    }

    return 0;
}


