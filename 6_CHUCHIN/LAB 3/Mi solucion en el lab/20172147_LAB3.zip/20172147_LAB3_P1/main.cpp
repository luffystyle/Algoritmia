/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: aml
 *
 * Created on 2 de noviembre de 2024, 08:05 AM
 */

#include<iostream>
#include <cstdlib>
#define N 13
using namespace std;

/*
 * 
 */
//merge(int arr,int medio,int fin

//cuenta ceros: ini>fin return 0 , arr1[medio]==dato -> sumotodo(arr[medio]+cuenta(ini,medio)+
//cuenta (medio+1,fin)
//sino solo los dos cuentaCero
//merge(for p=inicio,q=medio+1) mezcla,sobrante,sobrante2,paso a principal,ini==fin return 

void cuentaCeros(int *arr,int inicio,int fin,int dato,int &cuenta){
    if(inicio==fin)return ;
    int medio=(inicio+fin)/2;
//    if(arr[medio]==dato)cuenta++;
    if(arr[medio]==dato&& arr[medio]==arr[medio+1] && arr[medio]==arr[medio-1]){
        cuenta=3;
        return;
    }
    if(arr[medio]<dato){
        cuentaCeros(arr,medio+1,fin,dato,cuenta);
    }
    else{
        //voy izq
        cuentaCeros(arr,inicio,medio,dato,cuenta);
        if(cuenta==3)return;
    }

}

void merge(int *arr,int inicio,int medio,int fin){
    int aux[fin+1],p,q,m;
    for(p=inicio,q=medio+1,m=inicio;p<=medio&&q<=fin;m++){
        if(arr[p]<arr[q]){
            aux[m]=arr[p];
            p++;
        }
        else{
            aux[m]=arr[q];
            q++;
        }
    }
    while(p<=medio){
        aux[m]=arr[p];
        p++;
        m++;
    }
    while(q<=fin){
        aux[m]=arr[q];
        p++;
        q++;
    }
    //paso datos del auxiliar al arreglo
    for(int i=inicio;i<=fin;i++)arr[i]=aux[i];
}

void mergeSort(int *arr,int inicio,int fin){
    if(inicio==fin)return;
    int medio=(inicio+fin)/2;
    mergeSort(arr,inicio,medio);
    mergeSort(arr,medio+1,fin);
    merge(arr,inicio,medio,fin);
}

int main(int argc, char** argv) {
    int arr[N]={1,6,3,4,5,6,3,7,5,4,3,1,7};
    int n=13;
    //S 6 S 3 I 7 S 5 S 4 I 3 S 1 S 7
    //primero ordeno
     
    //se va a mostrar
    mergeSort(arr,0,n-1);
    arr[n-1]=7;
    //imprimir arreglo ordena
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
        
    //luego cuento y el que tiene mas de 2 encuentros es el que
    int max=0,nummax=0;
    int cuenta;
//cuenta ceros: ini>fin return 0 , arr1[medio]==dato -> sumotodo(arr[medio]+cuenta(ini,medio)+
//cuenta (medio+1,fin)
//sino solo los dos cuentaCero
    for(int i=0;i<n;i++){
        cuenta=0;
        cuentaCeros(arr,0,n-1,arr[i],cuenta);
        if(cuenta>2)nummax=arr[i];
    }
    cout<<"Empleado "<<nummax<<" ingreso y no  volvio a salir"<<endl;
    return 0;
}

