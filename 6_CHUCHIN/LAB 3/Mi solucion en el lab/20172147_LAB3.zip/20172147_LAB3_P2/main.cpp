/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: aml
 *
 * Created on 2 de noviembre de 2024, 09:24 AM
 */

#include <iostream>
#include <cstdlib>
#define N 10
using namespace std;

/*
 * 
 */

int encontrarMax(int *arr,int inicio,int fin){
    if(inicio==fin)return arr[inicio];
    int medio=(inicio+fin)/2;
    int maxIzq,maxDer;
    maxIzq=encontrarMax(arr,inicio,medio);
    maxDer=encontrarMax(arr,medio+1,fin);
    if(maxIzq>maxDer)return maxIzq;
    return maxDer;
    
}
int main(int argc, char** argv) {
    int matriz[N][N]={  {0,0,0,3,3,7,5,5,1,1},
                        {8,8,10,9,9,5,4,4,2,0},
                        {3,5,8,9,7,6,4,2,0,0},
                        {9,7,7,4,4,4,2,0,0,0},
                        {0,2,2,3,3,4,4,5,3,3},
                        {0,0,0,0,0,0,2,3,4,5},
                        {1,2,2,3,3,4,3,2,0,0},
                        {0,0,0,0,0,0,3,5,5,7},
                        {6,5,5,2,2,1,0,0,0,0},
                        {3,2,2,0,0,0,0,0,0,0}};
    int n=10;
    int tam=N*N;
    int arr[tam];
    
    //paso toda la matriz a una lineal
    for(int i=0,j=0,m=0;i<tam;m++,i++){
        arr[i]=matriz[j][m];
        if(i%9==0){
            j++;
            m=0;
        }    
    }
    
//    for(int i=0;i<tam;i++)cout<<arr[i]<<" ";
//    cout<<endl;
    int maximo=0,max;
    max=encontrarMax(arr,0,n-1);
//    cout<<max<<endl;
    if(maximo<max)maximo=max;

    

    cout<<"La maxima pureza de las muestras es: "<<max<<endl;
    
    
    return 0;
}

