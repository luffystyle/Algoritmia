/* 
 * File:   main.cpp
 * Author: Ana Roncal
 *
 * Created on 1 de setiembre de 2024, 22:58
 */

#include <iostream>
#include <iomanip>
#include "Cola.h"
#include "funcionesCola.h"
#include "funciones.h"
using namespace std;

/*
 * IMPLEMENTACIÓN DE UNA COLA
 * USANDO PUNTEROS CABEZA Y COLA
 * ALGORITMIA Y ESTRUCTURA DE DATOS 2024-2
 */


int main(int argc, char** argv) {

    struct Cola cola;
    construir(cola);

    cout << setw(62) << "RESULTADOS DE LA SIMULACIÓN" << endl;
    cout << setw(60) << "DEL DESPACHO DE ENTRADAS" << endl<<endl;
    cout << "Número de cajeros" << setw(20) << "Tiempo simulación" << setw(25);
    cout << "Clientes VIP atendidos" << setw(30);
    cout << "Clientes VIP no atendidos" << endl;
    simulacionDeColas(cola);

    return 0;
}

