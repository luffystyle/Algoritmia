/* 
 * File:   funciones.cpp
 * Author: ANA RONCAL
 * 
 * Created on 26 de setiembre de 2024, 13:25
 */

#include <iostream>
#include <iomanip>
#include "Cliente.h"
#include "funcionesCola.h"
#include "funcionesCliente.h"
using namespace std;
#define PROCESO 20
#define MAX_CAJEROS 1
#define NUM_CLIENTES 6

void simulacionDeColas(struct Cola &cola) {




    /* Mostrar resultados de la simulación */
//    cout << setw(8) << cajeros + 1;
//    cout << setw(22) << vipAtendidos;
//    cout << setw(22) << vipNoAtendidos << endl;

}
