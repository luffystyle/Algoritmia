/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   funciones.h
 * Author: anaro
 *
 * Created on 26 de setiembre de 2024, 13:25
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H
void simulacionDeColas(struct Cola & cola);

#endif /* FUNCIONES_H */
