/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   masFuncionesLista.h
 * Author: ferhu
 *
 * Created on 1 de abril de 2024, 22:36
 */

#ifndef MASFUNCIONESLISTA_H
#define MASFUNCIONESLISTA_H

void invertirLista(struct Lista &lista);
void rotarListaIzquierda(struct Lista &lista);
void intercambiarPares(struct Lista &lista);
void eliminarRepetidos(Lista& lista);

#endif /* MASFUNCIONESLISTA_H */

