#include <iostream>
#include <cmath>

#define N 8
#define T 4

using namespace std;

/*Parte a*/
struct Nodo{
    int elemento; /*Recuerde que este es el dato o los datos que maneja el nodo*/
    struct Nodo * siguiente;
};

/*Parte a*/
struct Lista{
    struct Nodo * cabeza;
    struct Nodo * cola;
    int longitud;
};

/*Valores iniciales de la lista*/
void construir(struct Lista & lista){
    lista.cabeza = NULL;
    lista.cola = NULL;
    lista.longitud = 0;
}

/*devuelve si la lista esta vacia 1, caso contrario 0 */
bool esListaVacia(const struct Lista & lista){
    return lista.cabeza == NULL;
}

/*DEVUELVE LA CANTIDAD DE ELEMENTOS DE LA LISTA*/
int longitud(struct Lista tad ){
    return tad.longitud;
}

/*CREA UN NUEVO ELEMENTO CON VALORES INICIALES*/
struct Nodo * crearNodo(int elemento, struct Nodo * siguiente){
    struct Nodo * nuevoNodo = new struct Nodo;
    nuevoNodo->elemento = elemento;
    nuevoNodo->siguiente = siguiente; 
    return nuevoNodo;
}


/*INSERTA UN ELEMENTO AL FINAL DE LA LISTA*/
void insertarAlFinal(struct Lista & lista, int elemento){
    struct Nodo * nuevoNodo = crearNodo(elemento, NULL);
    Nodo * ultimoNodo = lista.cola; /*obtiene el último nodo*/
    if (ultimoNodo == NULL){
        lista.cabeza = nuevoNodo;
        lista.cola = nuevoNodo;
    }
    else{
        ultimoNodo->siguiente = nuevoNodo;
        lista.cola = nuevoNodo;
    }            
    lista.longitud++;  
}

int retornaCabeza(const struct Lista & lista){
    if (esListaVacia(lista)){
        cout<<"No existe la cabeza por que la cola está vacía"<<endl;
        exit(1);
    }
    return lista.cabeza->elemento;
}

/*ELIMINA EL PRIMER ELEMENTO DE LA LISTA*/
void eliminaCabeza(struct Lista  & lista){
    struct Nodo * nodoEliminar = lista.cabeza;
    if (nodoEliminar == NULL ){
        cout<<"No se puede eliminar la cabeza pues la lista estÃ¡ vacÃ­a";
        exit(1);
    }
    else{
        lista.cabeza = lista.cabeza->siguiente;
        if(lista.cabeza == NULL)
            lista.cola = NULL;
        delete nodoEliminar;
        lista.longitud--;
    }
}

/*LIBERA LA MEMORIA*/
void destruirLista(struct Lista & tad){
    struct Nodo * recorrido = tad.cabeza;
    struct Nodo * eliminarNodo;
    
    while(recorrido != NULL){
        eliminarNodo = recorrido;        
        recorrido = recorrido->siguiente;
        delete eliminarNodo;
    }
    tad.cabeza = NULL;
    tad.cola = NULL;
    tad.longitud = 0;
}

void imprime(const struct Lista & lista){
       
    if (esListaVacia(lista)){
        cout<<"La cola esta vacía"<<endl;
    }
    else{
        struct Nodo * recorrido = lista.cabeza;
        while(recorrido != NULL){
            cout<<recorrido->elemento<<" ";
            recorrido = recorrido->siguiente;
        }   
    }
    cout<<endl;
}

int buscaElemento(int elemento, const struct Lista & lista){
	if (esListaVacia(lista)){
        cout<<"La Lista esta vacía"<<endl;
    }
    else{
        struct Nodo * recorrido = lista.cabeza;
        while(recorrido != NULL){
            if (recorrido->elemento == elemento){
            	return 1;
			}
            recorrido = recorrido->siguiente;
        }   
    }	
    return 0;
}

/*inserta un nodo siempre al inicio de la lista*/
void insertarAlInicio(struct Lista & tad, int elemento){
    /*Crea un nuevo nodo*/
    struct Nodo * nuevoNodo = new struct Nodo;
    nuevoNodo = crearNodo(elemento, tad.cabeza);
    
    tad.cabeza = nuevoNodo;
    tad.longitud++;
}

void eliminaNodo(struct Lista & tad, int elemento){
	struct Nodo * ultimo = NULL;
	struct Nodo * recorrido = tad.cabeza;
	/*Avanzo hasta encontrar el elemento*/
	/*Si no lo encuentra no elimina nada*/
	while((recorrido != NULL) and (recorrido->elemento != elemento)){
		ultimo = recorrido;
		recorrido = recorrido->siguiente;
	}
	
	if (recorrido != NULL){
		if (ultimo == NULL) /*Estoy al inicio de la lista*/
			tad.cabeza = recorrido->siguiente;
		else
			ultimo->siguiente = recorrido->siguiente;
		delete recorrido; /*libera la memoria*/
		tad.longitud--;
	}
}

int solucion=0;

void cargaBin(int i, int cromo[N], int n){
	int j;
	for (j=0; j<n; j++){
		cromo[j] = 0;
	}
	j = 0;
	while (i>0){
		cromo[j++] = i % T;
		i = i/T;
	}
}

int determinaSolucion(int pesosTotales[N],int nroBuses,int capacidad[T], int cantRescatados[T]){
	int combinaciones, cromo[N], rescatados[T], haySolucion;
	combinaciones = pow(T,nroBuses);
	for (int i=0; i<combinaciones; i++){
		cargaBin(i,cromo,nroBuses);
		/*Validar solucion*/
		for (int j=0; j<T; j++){
			rescatados[j] = 0;
			cantRescatados[j] = 0;
		}
		for (int j=0; j<nroBuses; j++){
			rescatados[cromo[j]] = rescatados[cromo[j]] + pesosTotales[j];
			cantRescatados[cromo[j]]++;
		}
		/*Verificamos si las tortuninjas salvaron al menos un bus y si esta dentro de su capacidad*/
		haySolucion = 1;
		for (int j=0; j<T; j++){
			if (rescatados[j]==0 || rescatados[j]>capacidad[j] || cantRescatados[j]>2){
				haySolucion = 0;
				break;
			}
		}
		if (haySolucion==1){
			solucion = i;
			break;
		}
	}
	return haySolucion;
}

void ordenarLista(Lista &ptrLista,int tipo){
	Nodo *ptrRecorrido, *ptrRecorridoNext;
	for (int i=0; i<ptrLista.longitud-1; i++){
		ptrRecorrido = ptrLista.cabeza;
		ptrRecorridoNext = ptrLista.cabeza->siguiente;
		for (int j=0; j<=ptrLista.longitud-2; j++){
			if (tipo==1){
				if (ptrRecorrido->elemento>ptrRecorridoNext->elemento){
					ptrRecorrido->siguiente = ptrRecorridoNext->siguiente;
					ptrRecorridoNext->siguiente = ptrRecorrido;
					if (j==0){
						ptrLista.cabeza = ptrRecorridoNext;
					}
					Nodo * ptrNodoAux =  ptrRecorrido->siguiente;
					ptrRecorrido = ptrRecorridoNext->siguiente;
					ptrRecorridoNext = ptrNodoAux;
				}
				else {
					ptrRecorrido = ptrRecorridoNext;
					ptrRecorridoNext = ptrRecorridoNext->siguiente;
				}
			}
			else {
				if (ptrRecorrido->elemento<ptrRecorridoNext->elemento){
					ptrRecorrido->siguiente = ptrRecorridoNext->siguiente;
					ptrRecorridoNext->siguiente = ptrRecorrido;
					if (j==0){
						ptrLista.cabeza = ptrRecorridoNext;
					}
					Nodo * ptrNodoAux =  ptrRecorrido->siguiente;
					ptrRecorrido = ptrRecorridoNext->siguiente;
					ptrRecorridoNext = ptrNodoAux;
				}
				else {
					ptrRecorrido = ptrRecorridoNext;
					ptrRecorridoNext = ptrRecorridoNext->siguiente;
				}
			}
		}
	}
}

void fusionar(Lista ptrListaInicio,Lista ptrListaFin){
	Nodo *ptrInicio, *ptrFin;
	int i=1;
	ptrInicio = ptrListaInicio.cabeza;
	ptrFin = ptrListaInicio.cabeza;
	ptrListaInicio.cabeza = ptrListaInicio.cabeza->siguiente;
	while (!esListaVacia(ptrListaInicio) && !esListaVacia(ptrListaFin)){
		if (i%2==1){
			ptrFin->siguiente = ptrListaFin.cabeza;
			ptrFin = ptrListaFin.cabeza;
			ptrListaFin.cabeza = ptrListaFin.cabeza->siguiente;
		}
		else {
			ptrFin->siguiente = ptrListaInicio.cabeza;
			ptrFin = ptrListaInicio.cabeza;
			ptrListaInicio.cabeza = ptrListaInicio.cabeza->siguiente;
		}
		i++;
	}
	if (!esListaVacia(ptrListaInicio)){
		ptrFin->siguiente = ptrListaInicio.cabeza;
		ptrFin = ptrListaInicio.cola;
	}
	if (!esListaVacia(ptrListaFin)){
		ptrFin->siguiente = ptrListaFin.cabeza;
		ptrFin = ptrListaFin.cola;
	}
}

void imprimeSolucion(Lista buses[N],int nroBuses, int cantRescatados[T]){
	int cromo[N], ini, fin;
	cargaBin(solucion,cromo,nroBuses);
	/*Recorro todas las tortuninjas*/
	for (int i=0; i<T; i++){
		if (i==0){
			cout << "Leonardo: " << endl;
		}
		else{
			if (i==1){
				cout << "Rafael: " << endl;
			}
			else {
				if (i==2){
					cout << "Donatelo: " << endl;
				}
				else{
					cout << "Miguel Angel: " << endl;
				}
			}
		}
//                cout<<"Cantidad de resatados: "<<cantRescatados[i]<<endl;
		if (cantRescatados[i]==1){
			/*Buscamos el camion rescatado por esa tortuninja para imprimirlo*/
			for (int j=0; j<nroBuses; j++){
				if (cromo[j]==i){
					imprime(buses[j]);
				}
			}
		}
		else {
			/*Buscamos los camiones a fusionar*/
			ini = -1; fin = -1;
			for (int j=0; j<nroBuses; j++){
				if (cromo[j]==i){
					if (ini==-1){
						ini = j;
					}
					else {
						fin = j;
					}
				}
			}
			ordenarLista(buses[ini],1);
			ordenarLista(buses[fin],2);
			fusionar(buses[ini],buses[fin]);
			imprime(buses[ini]);
		}
	}
}

int main(){
	/*Parte a*/
	Lista buses[N];
	int pesosTotales[N], capacidad[T], nroBuses, fin, peso, pesoTotal, haySolucion;
        int cantRescatados[T];

	cout << "Ingrese la cantidad de buses: ";
	cin >> nroBuses;
	cout << "Ingrese la capacidad de Leonardo: ";
	cin >> capacidad[0];
	cout << "Ingrese la capacidad de Rafael: ";
	cin >> capacidad[1];
	cout << "Ingrese la capacidad de Donatelo: ";
	cin >> capacidad[2];
	cout << "Ingrese la capacidad de Miguel Angel: ";
	cin >> capacidad[3];
	for (int i=0; i<nroBuses; i++){
		construir(buses[i]);
		fin = 0;
		pesoTotal = 0;
		cout << "Ingrese los pesos del Bus Nro. " << i+1 << endl;
		while (!fin){
			cin >> peso;
			if (peso>0){
				insertarAlFinal(buses[i],peso);
				pesoTotal = pesoTotal + peso;
			}
			else {
				fin = 1;
			}
		}
		pesosTotales[i] = pesoTotal;
	}
	/*Parte b*/
	haySolucion = determinaSolucion(pesosTotales,nroBuses,capacidad, cantRescatados);
        
        cout<<endl<<"Los resultado:"<<endl;
	if (haySolucion){
		/*Parte c*/
		cout << "Las TortuNinjas completaron su mision"<< endl;
                cout<<"Nro. solución: "<<solucion<<endl;
		imprimeSolucion(buses,nroBuses, cantRescatados);
	}
	else {
		cout << "Las tortuninjas fracasaron en su misión";	
	}
	/*Imprime buses*/
        
        cout<<endl<<"Los buses:"<<endl;
	for (int i=0; i<nroBuses; i++){
		imprime(buses[i]);
	}
	return 0;
}
