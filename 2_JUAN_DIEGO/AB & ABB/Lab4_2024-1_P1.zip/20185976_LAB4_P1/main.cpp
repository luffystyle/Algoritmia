/* 
 * File:   main.cpp
 * Author: ANA RONCAL
 * Created on 18 de septiembre de 2023, 05:39 PM
 */

#include <iostream>
#include "ArbolBinarioBusqueda.h"
#include "ArbolBinario.h"
#include "Cola.h"
using namespace std;
#include "funcionesArbolesBB.h"
#include "funcionesArbolesBinarios.h"
#include "funcionesCola.h"
/*
 * ESTRUCTURA ÁRBOL BINARIO BÚSQUEDA 2024-1 
 */
int numeroHojasRecursivo(struct NodoArbol * nodo){
    if(esNodoVacio(nodo))
        return 0;
    else if ( esNodoVacio(nodo->izquierda) and esNodoVacio(nodo->derecha) )
        return 1;
    else
        return numeroHojasRecursivo(nodo->izquierda) + numeroHojasRecursivo(nodo->derecha);
}

void aplicar_arbol(ArbolBinario & arbol1, ArbolBinario arbol2){
    // se utilizan dos colas para poder obtener ir recorriendo tanto el AB como el ABB
    struct Cola cola1,cola2;    
    construir(cola1);
    construir(cola2);
    if(!esArbolVacio(arbol1)){
        encolar(cola1,arbol1.raiz);
        encolar(cola2,arbol2.raiz);
        while(!esColaVacia(cola1)){
            //Aqui se operan los nodos al sumar al nodo paquetes, el nodo sistema
            NodoArbol* nodo1 = desencolar(cola1);
            NodoArbol* nodo2 = desencolar(cola2);
            nodo1->elemento += numeroNodosRecursivo(nodo2) - numeroHojasRecursivo(nodo2);
//            imprimeNodo(nodo);
            if(nodo1->izquierda!=nullptr)
                encolar(cola1,nodo1->izquierda);
                encolar(cola2,nodo2->izquierda);
            if(nodo1->derecha!=nullptr)
                encolar(cola1,nodo1->derecha);
                encolar(cola2,nodo2->derecha);
        }
    }
    cout<<endl;
}
int determinar_anomalia(NodoArbol * raiz){
    //Determina que los nodos de la izquierda sean simepre menores que los de la derecha
    if(raiz->izquierda==nullptr || raiz->derecha==nullptr)return 1;
    NodoArbol * actual = raiz;
    //Verifica si los elementos de la izquierda son menores
    if(actual->elemento > actual->izquierda->elemento){
        return determinar_anomalia(raiz->izquierda);
    }else{
        return 0;
    }
    //verifica si los elementos de la derecha son mayores
    if(actual->elemento<actual->derecha->elemento){
        return determinar_anomalia(raiz->derecha);
    }else{
        return 0;
    }
}
int main(int argc, char** argv) {
    
    struct ArbolBinarioBusqueda arbol_paquetes;
    construir(arbol_paquetes);
    //construyendo el ABB
    insertar(arbol_paquetes,5);
    insertar(arbol_paquetes,3);
    insertar(arbol_paquetes,9); 
    cout<<endl<<"Arbol paquetes: "<<endl;
    recorrerPreOrden(arbol_paquetes.arbolBinario);
    cout<<endl;
//    recorreAmplitud(arbol_paquetes.arbolBinario);
    struct ArbolBinario arbol_sistema;
    construir(arbol_sistema);
    
    cout<<endl;
    //Construyendo el ab
    ArbolBinario arbol1,arbol2,arbol3,arbol4;
    
    plantarArbolBinario(arbol1,nullptr,2,nullptr);
    plantarArbolBinario(arbol2,nullptr,3,nullptr);
    plantarArbolBinario(arbol3,arbol1,7,arbol2);
    plantarArbolBinario(arbol4,nullptr,8,nullptr);
    plantarArbolBinario(arbol_sistema,arbol3,1,arbol4);
    cout<<endl<<"Arbol sistema: "<<endl;
    recorrerPreOrden(arbol_sistema);
    
    aplicar_arbol(arbol_paquetes.arbolBinario,arbol_sistema);
    cout<<endl<<"Arbol resultado en preOrden"<<endl;
    recorrerPreOrden(arbol_paquetes.arbolBinario);
    int valido=determinar_anomalia(arbol_paquetes.arbolBinario.raiz);
    if(valido){
        cout<<endl<<"Sin eventos sospechosos"<<endl;
    }else{
        cout<<"Anomalia detectada"<<endl;
    }
    
      
    return 0;
}

//   struct ArbolBinarioBusqueda arbol;
//    int auxiliarElemento;
//    
//    construir(arbol);
//    insertar(arbol, 100);
//    insertar(arbol, 50);
//    insertar(arbol, 150);
//    insertar(arbol, 125);
//    insertar(arbol, 175);
//    insertar(arbol, 200);
//    insertar(arbol, 25);
//    insertar(arbol, 75);
//    
//   
//    preOrden(arbol); cout<<endl;
//    enOrden(arbol);  cout<<endl;
//    postOrden(arbol); cout<<endl;
//    cout<<"Se encuentra 125 en árbol: "<<buscaArbol(arbol, 125)<<endl;
//     
//    eliminarNodo(arbol, 125);
//    enOrden(arbol);   cout<<endl;
//      
//    auxiliarElemento = minimoNodoABB(arbol);
//    cout<<"Mínimo ABB: "<<auxiliarElemento<<endl;
//    //LISTO
//    auxiliarElemento = maximoNodoABB(arbol);
//    cout<<"Máximo ABB: "<<auxiliarElemento<<endl;
//        
//    cout<<"Sumar nodos: "<<sumarNodos(arbol)<<endl;
//    
//    destruirArbolBB(arbol);