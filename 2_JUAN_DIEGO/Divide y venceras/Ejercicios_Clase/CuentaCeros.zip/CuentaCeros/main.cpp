/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 22 de abril de 2024, 11:24
 */

#include <cstdlib>
#include <iostream>

using namespace std;
#define N 7

/*
 * 
 */

int cuentaCeros(int arreglo[N],int inicio,int fin,int cuenta){
    if (inicio>fin){
        return cuenta;
    }
    int medio = (inicio+fin)/2;
    if (arreglo[medio]==0){
        if (arreglo[medio-1]==1){
            return cuenta + fin - medio + 1;
        }
        else {
            return cuentaCeros(arreglo,inicio,medio-1,cuenta+fin-medio+1);
        }
    }
    else{
        return cuentaCeros(arreglo,medio+1,fin,cuenta);
    }
}

int main(int argc, char** argv) {
    int arreglo[N] = {0,0,0,0,0,0,0};
    int n=7;
    cout << "La cantidad de ceros es: " << cuentaCeros(arreglo,0,n-1,0);
    return 0;
}

