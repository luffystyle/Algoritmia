/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 22 de abril de 2024, 11:01
 */

#include <cstdlib>
#include <iostream>
#define N 11

using namespace std;

/*
 * 
 */

int buscarNoRepite(int arreglo[N],int inicio,int fin){
    if (inicio>fin){
        return -1; /*-1 indica que todos tienen su par*/
    }
    if (inicio==fin){
        return arreglo[inicio];
    }
    int medio = (inicio+fin)/2;
    if (medio%2==1){
        if (arreglo[medio-1]==arreglo[medio]){
            return buscarNoRepite(arreglo,medio+1,fin);
        }
        else{
            return buscarNoRepite(arreglo,inicio,medio-1);
        }
    }
    else {
        if (arreglo[medio]==arreglo[medio+1]){
            return buscarNoRepite(arreglo,medio+2,fin);
        }
        else {
            return buscarNoRepite(arreglo,inicio,medio);
        }
    }
}

int main(int argc, char** argv) {
    int arreglo[N] = {1,1,3,3,4,4,5,5,8,8,9};
    int n=11;
    cout << "El elemento que no se repite es: " << buscarNoRepite(arreglo,0,n-1);
    return 0;
}