/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 22 de abril de 2024, 10:29
 */

#include <cstdlib>
#include <iostream>
#define N 8

using namespace std;

/*
 * 
 */

int busquedaBinaria(int arreglo[N],int elementoBuscado,int inicio,int fin){
    /*Caso base cuano no encuentro el elemento*/
    if (inicio>fin){
        return -1;
    }
    int medio = (inicio+fin)/2; /*Esto es aplicar divide y venceras*/
    if (arreglo[medio]==elementoBuscado){
        return medio;
    }
    else{
        if (elementoBuscado>arreglo[medio]){
            return busquedaBinaria(arreglo,elementoBuscado,medio+1,fin); /*Esto es aplicar divide y venceras*/
        }
        else{
            return busquedaBinaria(arreglo,elementoBuscado,inicio,medio-1); /*Esto es aplicar divide y venceras*/
        }
    }
}

int main(int argc, char** argv) {
    int arreglo[N] = {1,5,7,12,14,18,21,31};
    int n = 8, elementoBuscado=21;
    int indice = busquedaBinaria(arreglo,elementoBuscado,0,n-1);
    if (indice!=-1){
        cout << "El elemento se encuentra en el arreglo en la posicion " << indice;
    }
    else {
        cout << "El elemento no se encuentra en el arreglo";
    }
    return 0;
}