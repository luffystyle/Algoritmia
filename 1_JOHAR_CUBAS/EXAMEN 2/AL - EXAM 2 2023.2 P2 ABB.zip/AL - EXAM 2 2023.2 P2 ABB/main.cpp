/* 
 * Nombre:   Johar Ricarte Cubas Castro
 * Codigo:   20195806
 */

#include <cstdlib>
#include <cmath>
#include <iostream>
#include <iomanip>

using namespace std;
#include "ArbolBinario.h"
#include "ArbolBinarioBusqueda.h"
#include "funcionesArbolesBB.h"
#include "funcionesArbolesBinarios.h"

int validaLetra(char * palabra,char letra){
    int existe = 0;
    for(int i=0;palabra[i]!='\0';i++){
        if(letra == palabra[i]){
            existe = 1;
            break;
        }
    }
    return existe;
}

int validacionExiste(char * palabra,char *letras,int pos){
    int aux[6];
    for(int i=0;i<pos;i++) aux[i]=letras[i];
    int existe;
    int contador =0;
    for(int i=0;palabra[i]!='\0';i++){
        contador ++;
        existe=0;
        for(int j=0;j<pos;j++){
            if(aux[j]==palabra[i]){
                existe =1;
                aux[j]=' ';
                break;
            }
        }
        if(existe !=1){
            break;
        }
        
    }
    
    if(existe ==1 and contador == pos){
        return 1;
    }else{
        return 0;
    }

    
}

int validacionPalabra(struct NodoArbol *raiz,char *palabra,char *letras,int pos){
    if(raiz == nullptr){
        return 0;
    }
    
    if(validaLetra(palabra,raiz->letra)==1){
        letras[pos++] = raiz->letra;
    }else{
        return 0;
    }
    
    if(raiz->izquierda == nullptr and raiz->derecha == nullptr){
        if(validacionExiste(palabra,letras,pos)==1){
            return 1;
        }else{
            return 0;
        }
    }
    
    return validacionPalabra(raiz->izquierda,palabra,letras,pos) + validacionPalabra(raiz->derecha,palabra,letras,pos);
}

int main(int argc, char** argv) {
    struct ArbolBinarioBusqueda arbol;
    construir(arbol);
    insertar(arbol,30,'M');
    insertar(arbol,20,'U');
    insertar(arbol,40,'I');
    insertar(arbol,15,'E');
    insertar(arbol,23,'N');
    insertar(arbol,22,'R');
    insertar(arbol,25,'D');
    insertar(arbol,24,'O');
    insertar(arbol,38,'C');
    insertar(arbol,37,'C');
    insertar(arbol,36,'O');
    insertar(arbol,45,'N');
    insertar(arbol,43,'A');
    insertar(arbol,42,'F');
    insertar(arbol,44,'T');
    
    char palabra[6][8]={{'H','I','J','O','\0'},
                        {'F','I','N','A','L','\0'},
                        {'M','U','N','D','O','\0'},
                        {'D','E','L','\0'},
                        {'D','I','A','\0'},
                        {'C','I','C','L','O','\0'}};
    int cantiPalabras=6;
    char aux[7];
    for(int i=0;i<cantiPalabras;i++){
        int valido = validacionPalabra(arbol.arbolBinario.raiz,palabra[i],aux,0);
        if(valido==1){
            for(int j=0;palabra[i][j]!='\0';j++){
                cout<<palabra[i][j];
            }
            cout<<endl;
        }
        
    }
    
    return 0;
}

